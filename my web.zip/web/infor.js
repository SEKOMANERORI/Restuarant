function prices() {
  var first=document.getElementById("Lemon");
  var final=document.getElementById("calc");

  var Lemon=first.value;
  var total=final.value;

  total=Lemon*25-10;

}
